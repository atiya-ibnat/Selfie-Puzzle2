package com.bubt.selfipuzzle.uitil;

/**
 * @author Bazlur Rahman Rokon
 * @since 7/12/17.
 */
public class ExternalStorageNotAccessibleException extends Exception {
    private String externalStorageState;

    public ExternalStorageNotAccessibleException(String externalStorageState) {
        this.externalStorageState = externalStorageState;
    }

    public String getExternalStorageState() {
        return externalStorageState;
    }
}
