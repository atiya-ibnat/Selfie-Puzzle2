package com.bubt.selfipuzzle.uitil;

public class CameraUnavailableException extends Exception {
    public CameraUnavailableException(Throwable throwable) {
        super(throwable);
    }
}
