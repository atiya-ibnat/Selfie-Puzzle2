package com.bubt.selfipuzzle.uitil;


import android.graphics.Bitmap;

import java.util.Objects;

public class Slice {
    private Bitmap bitmap;
    private int id;

    public Slice() {

    }

    public Slice(Bitmap bitmap, int id) {
        this.bitmap = bitmap;
        this.id = id;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Slice slice = (Slice) o;
        return id == slice.id &&
                Objects.equals(bitmap, slice.bitmap);
    }

    @Override
    public int hashCode() {
        return Objects.hash(bitmap, id);
    }
}
