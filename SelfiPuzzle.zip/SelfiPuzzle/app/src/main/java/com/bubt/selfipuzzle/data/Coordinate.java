package com.bubt.selfipuzzle.data;


public class Coordinate {

    public int row;
    public int column;

    public Coordinate(int row, int column) {
        this.row = row;
        this.column = column;
    }

    public boolean matches(Coordinate coordinate) {
        return coordinate.row == row && coordinate.column == column;
    }

    public boolean sharesAxisWith(Coordinate coordinate) {
        return (row == coordinate.row || column == coordinate.column);
    }

    public boolean isToRightOf(Coordinate coordinate) {
        return sharesAxisWith(coordinate) && (column > coordinate.column);
    }

    public boolean isToLeftOf(Coordinate coordinate) {
        return sharesAxisWith(coordinate) && (column < coordinate.column);
    }

    public boolean isAbove(Coordinate coordinate) {
        return sharesAxisWith(coordinate) && (row < coordinate.row);
    }

    public boolean isBelow(Coordinate coordinate) {
        return sharesAxisWith(coordinate) && (row > coordinate.row);
    }

    @Override
    public String toString() {
        return "[R: " + row + " C:" + column + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Coordinate)) return false;

        Coordinate that = (Coordinate) o;

        if (column != that.column) return false;
        if (row != that.row) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = row;
        result = 31 * result + column;
        return result;
    }
}

