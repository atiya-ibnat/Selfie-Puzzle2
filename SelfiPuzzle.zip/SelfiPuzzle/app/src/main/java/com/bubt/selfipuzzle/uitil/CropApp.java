package com.bubt.selfipuzzle.uitil;


import android.content.Intent;
import android.graphics.drawable.Drawable;

public class CropApp {
    public CharSequence title;
    public Drawable icon;
    public Intent appIntent;
}
