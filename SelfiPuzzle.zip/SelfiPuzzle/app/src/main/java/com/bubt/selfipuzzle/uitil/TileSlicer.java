package com.bubt.selfipuzzle.uitil;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;

import com.bubt.selfipuzzle.ui.TileView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Slices original bitmap into tiles and adds border. Provides randomized or
 * ordered access to tiles.
 * <p>
 * Based on
 * https://github.com/thillerson/Android-Slider-Puzzle/blob/master/src/com
 * /tackmobile/TileServer.java
 *
 * @author David Vavra
 */
public class TileSlicer {
    private static final String TAG = "TileSlicer";

    private Bitmap original;
    private int tileSize, gridSize;
    private ArrayList<Bitmap> slices;
    private int lastSliceServed;
    private List<Integer> sliceOrder;
    private Context context;
    private ArrayList<Integer> sliceOrderPersist;
    private List<Slice> before;
    private List<Slice> after;
    private List<Slice> sliceList;

    /**
     * Initializes TileSlicer.
     *
     * @param original Bitmap which should be sliced
     * @param gridSize Grid size, for example 4 for 4x4 grid
     */
    public TileSlicer(Bitmap original, int gridSize, Context context) {
        super();
        this.original = original;
        this.gridSize = gridSize;
        this.tileSize = original.getWidth() / gridSize;
        this.context = context;
        slices = new ArrayList<>();
        sliceList = new ArrayList<>();
        sliceOriginal();
    }

    /**
     * Slices original bitmap and adds border to slices.
     */
    private void sliceOriginal() {
        sliceOrderPersist = new ArrayList<>();
        int x, y;
        Bitmap bitmap;
        lastSliceServed = 0;
        int count = 0;
        for (int rowI = 0; rowI < gridSize; rowI++) {
            for (int colI = 0; colI < gridSize; colI++) {
                // don't slice last part - empty slice
                if (rowI == gridSize - 1 && colI == gridSize - 1) {
                    continue;
                } else {
                    x = rowI * tileSize;
                    y = colI * tileSize;
                    // slice
                    bitmap = Bitmap.createBitmap(original, y, x, tileSize, tileSize);
                    // draw border lines
                    Canvas canvas = new Canvas(bitmap);
                    Paint paint = new Paint();
                    paint.setColor(Color.parseColor("#fbfdff"));
                    int end = tileSize - 1;
                    canvas.drawLine(0, 0, 0, end, paint);
                    canvas.drawLine(0, end, end, end, paint);
                    canvas.drawLine(end, end, end, 0, paint);
                    canvas.drawLine(end, 0, 0, 0, paint);
                    slices.add(bitmap);

                    sliceOrderPersist.add(count);
                    sliceList.add(new Slice(bitmap, count));
                    count++;
                }
            }
        }
        // remove reference to original bitmap
        //original = null;
    }


    /**
     * Randomizes slices in case no previous state is available.
     */
    public void randomizeSlices() {
        // randomize first slices
        before = new ArrayList<>(sliceList);

        //Collections.shuffle(slices);
        Collections.shuffle(sliceList);

        // last one is empty slice
        slices.add(null);
        sliceOrder = null;

        // last one is empty slice
        slices.add(null);
        sliceList.add(null);
        sliceOrder = null;
        before.add(null);
        after = new ArrayList<>(sliceList);

        Log.d(TAG, "before: " + getBeforeId());
        Log.d(TAG, "after: " + getAfterId());
    }


    /**
     * Sets slice order in case of previous instance is available, eg. from
     * screen rotation.
     *
     * @param order list of integers marking order of slices
     */
    public void setSliceOrder(List<Integer> order) {
        ArrayList<Bitmap> newSlices = new ArrayList<Bitmap>();
        for (int o : order) {
            if (o < slices.size()) {
                newSlices.add(slices.get(o));
            } else {
                // empty slice
                newSlices.add(null);
            }
        }
        sliceOrder = order;
        slices = newSlices;
    }

    /**
     * Serves slice and creates a tile for gameboard.
     *
     * @return TileView with the image or null if there are no more slices
     */
    public TileView getTile() {
        TileView tile = null;
        if (sliceList.size() > 0) {
            int originalIndex;
            if (sliceOrder == null) {
                originalIndex = lastSliceServed++;
            } else {
                originalIndex = sliceOrder.get(lastSliceServed++);
            }
            tile = new TileView(context, originalIndex);
            if (sliceList.get(0) == null) {
                // empty slice
                tile.setEmpty(true);
                tile.setId(gridSize * gridSize - 1);
            } else {
                Slice slice = sliceList.get(0);
                Log.d(TAG, "Slice ID: " + slice.toString());
                tile.setId(slice.getId());
                tile.setImageBitmap(slice.getBitmap());
                sliceList.remove(slice);
            }
        }
        Log.d(TAG, "Tile ID: " + tile.getId());

        return tile;
    }

    public ArrayList<Integer> getSliceOrderPersist() {
        return sliceOrderPersist;
    }

    public String getBeforeId() {
        return before.toString();
    }

    public String getAfterId() {
        return after.toString();
    }


}
